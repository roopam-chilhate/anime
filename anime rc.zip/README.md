 -[LIVE](https://anime-suem.netlify.app/)
 
 -[POST](https://dev.to/sandyabhi/anime-list-reactjs-jikan-api-2njp)

How to Run

``Using yarn``

1) "yarn "
2) "yarn start"

``Using npm``

1) "npm i "
2) "npm start"


