import "../styles/Footer.css";
import GitHubIcon from "@material-ui/icons/GitHub";
import LinkedInIcon from "@material-ui/icons/LinkedIn";

function Footer() {
  return (
    <footer>
   <div className="footer">
    Thank You
   </div>
    
    </footer>
  );
}

export default Footer;
